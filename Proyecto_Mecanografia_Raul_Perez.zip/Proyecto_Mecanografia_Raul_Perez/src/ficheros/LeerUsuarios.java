package ficheros;

import java.util.ArrayList;

public class LeerUsuarios {

	public LeerUsuarios() {
		
	}
	public ArrayList<Usuario> users() {
		ArrayList<Usuario> usuarios = new ArrayList<>();
		return usuarios;
	}
}
